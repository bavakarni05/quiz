require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const http = require('http');
const socketIo = require('socket.io');
const connectDB = require('./config/db');
const { Quiz, generateHostPin } = require('./models/Quiz');
const Participant = require('./models/Participant');

console.log('Quiz after import:', Quiz);
console.log('Participant after import:', Participant);

// Initialize Express app
const app = express();
const server = http.createServer(app);

// Configure CORS
const allowedOrigins = process.env.ALLOWED_ORIGINS?.split(',') || [
  'http://localhost:5173',
  'http://localhost:5174',
  'http://localhost:3000',
  'http://localhost:3001'
];

// Socket.IO configuration
const io = socketIo(server, {
  cors: {
    origin: function (origin, callback) {
      if (!origin || allowedOrigins.indexOf(origin) !== -1) {
        callback(null, true);
      } else {
        callback(new Error('Not allowed by CORS'));
      }
    },
    methods: ['GET', 'POST'],
    credentials: true
  }
});

// Middleware
app.use(cors({
  origin: function (origin, callback) {
    if (!origin) return callback(null, true);
    if (allowedOrigins.indexOf(origin) === -1) {
      return callback(new Error('Not allowed by CORS'), false);
    }
    return callback(null, true);
  },
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With', 'Accept']
}));

app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// Store active rooms (This map can be used for quick lookups, but database is source of truth)
const activeRooms = new Map();
const questionTimers = new Map(); // Store timers for each room

// Helper function to send the current question and start its timer
const sendQuestion = async (roomCode, quiz, io) => {
  const room = activeRooms.get(roomCode);
  if (!room || !quiz) {
    console.log(`[sendQuestion] Room ${roomCode} or quiz not found in activeRooms/DB. Aborting sendQuestion.`);
    return;
  }

  // Clear any existing timer for this room
  if (questionTimers.has(roomCode)) {
    clearInterval(questionTimers.get(roomCode));
    questionTimers.delete(roomCode);
    console.log(`[sendQuestion] Cleared existing timer for room ${roomCode}.`);
  }

  const currentQuestion = quiz.questions[quiz.currentQuestionIndex];
  if (!currentQuestion) {
    console.log(`[sendQuestion] No more questions found for room ${roomCode} at index ${quiz.currentQuestionIndex}. Quiz questions length: ${quiz.questions.length}. Calling endQuiz.`);
    await endQuiz(roomCode, quiz, io);
    return;
  }

  // Update current question start time and save to database
  quiz.currentQuestionStartTime = new Date();
  await quiz.save();
  console.log(`[sendQuestion] Quiz ${roomCode} currentQuestionStartTime updated and saved.`);

  // Reset answers for the new question
  room.answers = new Map();
  // Initialize answer counts for the new question for the host's view
  const initialAnswersCount = {};
  currentQuestion.options.forEach(option => {
    initialAnswersCount[option] = 0;
  });
  console.log(`[sendQuestion] Emitting 'updateAnswers' to room ${roomCode} with counts:`, initialAnswersCount);
  io.to(roomCode).emit('updateAnswers', { answersCount: initialAnswersCount });

  console.log(`[sendQuestion] Emitting 'newQuestion' to room ${roomCode} for question index ${quiz.currentQuestionIndex}`);
  io.to(roomCode).emit('newQuestion', {
    question: {
      question: currentQuestion.question,
      options: currentQuestion.options,
      timeLimit: currentQuestion.timeLimit,
    },
    questionIndex: quiz.currentQuestionIndex,
    timeLimit: currentQuestion.timeLimit,
  });

  // Start the timer for the question
  let timeLeft = currentQuestion.timeLimit;
  console.log(`[sendQuestion] Starting timer for room ${roomCode} with ${timeLeft}s.`);
  const timerInterval = setInterval(async () => {
    io.to(roomCode).emit('timerUpdate', { timeLeft });
    if (timeLeft <= 0) {
      clearInterval(timerInterval);
      questionTimers.delete(roomCode);
      console.log(`[sendQuestion] Timer for room ${roomCode} expired. Calculating scores and emitting leaderboard.`);
      await calculateScoresAndEmitLeaderboard(roomCode, quiz, io); 
    } else {
      timeLeft--;
    }
  }, 1000);
  questionTimers.set(roomCode, timerInterval);
};

// Helper to calculate scores and emit leaderboard
const calculateScoresAndEmitLeaderboard = async (roomCode, quiz, io) => {
  console.log(`[calculateScoresAndEmitLeaderboard] Entering function for room ${roomCode}.`);
  const room = activeRooms.get(roomCode);
  console.log(`[calculateScoresAndEmitLeaderboard] Active room from activeRooms map: ${!!room}. Quiz object received as argument: ${!!quiz}.`);

  // Crucial check: If room is not found in activeRooms, it means it was deleted prematurely.
  // We should still try to calculate scores and emit leaderboard if quiz object is available.
  if (!quiz) {
    console.log(`[calculateScoresAndEmitLeaderboard] Quiz object is null for room ${roomCode}. Aborting score calculation and leaderboard emission.`);
    return;
  }

  const participants = await Participant.find({ roomCode: String(roomCode) }); // Always get latest participants from DB
  console.log(`[calculateScoresAndEmitLeaderboard] Participants from DB for room ${roomCode}:`, participants.map(p => p.username));

  const currentQuestion = quiz.questions[quiz.currentQuestionIndex];
  if (!currentQuestion) {
    console.log(`[calculateScoresAndEmitLeaderboard] Current question not found for room ${roomCode} at index ${quiz.currentQuestionIndex}. Quiz questions length: ${quiz.questions.length}.`);
    return; // Should not happen if sendQuestion correctly checks for no more questions
  }

  // Calculate scores for the question that just ended
  console.log(`[calculateScoresAndEmitLeaderboard] Calculating scores for room ${roomCode}, question index ${quiz.currentQuestionIndex}. Total answers in room.answers map: ${room ? room.answers.size : 0}.`);
  if (room && room.answers) { // Only process answers if the room object and its answers map are still available
    for (const [socketId, answerData] of room.answers.entries()) {
      if (answerData.questionIndex === quiz.currentQuestionIndex && answerData.isCorrect) {
        const participant = participants.find(p => p.socketId === socketId);
        if (participant) {
          participant.score += 100; 
          participant.correctAnswers += 1;
          await participant.save();
          console.log(`[calculateScoresAndEmitLeaderboard] Updated score for ${participant.username} (score: ${participant.score}).`);
        }
      }
    }
  } else {
    console.warn(`[calculateScoresAndEmitLeaderboard] Room or room.answers not found for room ${roomCode}. Skipping in-memory answer processing.`);
  }

  // Sort participants by score for leaderboard
  const leaderboard = participants.sort((a, b) => b.score - a.score).map(p => ({
    id: p._id,
    username: p.username,
    score: p.score,
  }));

  io.to(roomCode).emit('questionEnd', {
    leaderboard,
    correctAnswer: currentQuestion.correctAnswer,
    // We remove waitingForHost as it's now automatic progression
  });
  console.log(`[calculateScoresAndEmitLeaderboard] Emitted 'questionEnd' to room ${roomCode}. Leaderboard:`, leaderboard);

  // After emitting leaderboard, initiate advanceQuiz (if host side logic takes over from here)
  // If `advanceQuiz` is called from the timer side now, it needs to be carefully managed
};

// Helper to end the quiz
const endQuiz = async (roomCode, quiz, io) => {
  console.log(`[endQuiz] Starting quiz completion process for room ${roomCode}.`);
  if (questionTimers.has(roomCode)) {
    clearInterval(questionTimers.get(roomCode));
    questionTimers.delete(roomCode);
    console.log(`[endQuiz] Cleared timer for room ${roomCode}.`);
  }

  if (quiz) { // Ensure quiz object exists before trying to save it
    quiz.status = 'completed';
    quiz.completedAt = new Date();
    await quiz.save();
    console.log(`[endQuiz] Quiz ${roomCode} status set to completed and saved to DB.`);
  } else {
    console.warn(`[endQuiz] Quiz object not found for room ${roomCode}, cannot update status in DB.`);
  }

  // Get final leaderboard (ensure it's fetched before deleting room if needed)
  const finalParticipants = await Participant.find({ roomCode: String(roomCode) }).sort({ score: -1 }); // Ensure roomCode is a string
  const finalLeaderboard = finalParticipants.map(p => ({
    id: p._id,
    username: p.username,
    score: p.score,
  }));

  io.to(roomCode).emit('quizCompleted', { finalLeaderboard });
  console.log(`[endQuiz] Emitted 'quizCompleted' to room ${roomCode}. Final Leaderboard:`, finalLeaderboard);
  
  // IMPORTANT: Delete room from activeRooms ONLY AFTER everything else is done
  if (activeRooms.has(roomCode)) {
    activeRooms.delete(roomCode); 
    console.log(`[endQuiz] Removed room ${roomCode} from activeRooms map.`);
  } else {
    console.warn(`[endQuiz] Room ${roomCode} not found in activeRooms map, already deleted?`);
  }

  // Also delete all participants for this room from the database to clean up
  await Participant.deleteMany({ roomCode: String(roomCode) }); 
  console.log(`[endQuiz] Deleted all participant records for room ${roomCode} from database.`);
};

// Helper to advance to the next question or end the quiz (now triggered by host)
const advanceQuiz = async (roomCode, quiz, io) => {
  console.log(`[advanceQuiz] Attempting to advance quiz for room ${roomCode}. Current index: ${quiz ? quiz.currentQuestionIndex : 'quiz is null'}. Quiz questions length: ${quiz ? quiz.questions.length : 'quiz is null'}.`);
  if (!quiz) {
    console.error(`[advanceQuiz] Cannot advance quiz for room ${roomCode} because quiz object is null.`);
    return; // Prevent errors if quiz is null
  }

  quiz.currentQuestionIndex++;
  console.log(`[advanceQuiz] Incremented currentQuestionIndex to ${quiz.currentQuestionIndex} for room ${roomCode}.`);

  if (quiz.currentQuestionIndex < quiz.questions.length) {
    await quiz.save(); // Save the new question index
    console.log(`[advanceQuiz] Quiz for room ${roomCode} moved to question index ${quiz.currentQuestionIndex}. Calling sendQuestion.`);
    
    // Update the quiz object in activeRooms after saving (it might be stale if re-fetched)
    if (activeRooms.has(roomCode)) {
      activeRooms.get(roomCode).quiz = quiz; 
      console.log(`[advanceQuiz] Updated activeRooms for room ${roomCode} with latest quiz object after increment.`);
    }
    await sendQuestion(roomCode, quiz, io);

  } else {
    console.log(`[advanceQuiz] Quiz for room ${roomCode} has no more questions. Calling endQuiz.`);
    await endQuiz(roomCode, quiz, io); // Only end quiz here if all questions are done
  }
};

// MongoDB connection
connectDB().then(() => {
  console.log('MongoDB connection established');

  // Socket.IO connection handling - MOVED HERE
  io.on('connection', (socket) => {
    console.log('New client connected:', socket.id);

    socket.on('createRoom', async ({ questions, roomCode }, callback) => {
      try {
        console.log('[createRoom] Received room creation request with code:', roomCode);
        const hostPin = generateHostPin();
        
        const quiz = new Quiz({
          roomCode: String(roomCode), // Ensure roomCode is a string
          title: String(roomCode), // Ensure roomCode is a string
          hostId: socket.id,
          hostPin: hostPin,
          questions,
          status: 'waiting',
          currentQuestionIndex: 0,
          participants: []
        });

        await quiz.save();
        console.log('[createRoom] Room created with title:', roomCode, 'and hostPin:', hostPin);
        
        callback({
          success: true,
          roomCode: roomCode,
          hostPin: hostPin // Return the hostPin to the host
        });
      } catch (error) {
        console.error('[createRoom] Error creating room:', error.message);
        callback({ success: false, error: 'Failed to create room' });
      }
    });

    socket.on('joinAsHost', async ({ roomCode, hostPin }, callback) => {
      console.log(`[joinAsHost] Socket ${socket.id} attempting to join as host for room ${roomCode} with PIN ${hostPin}`);
      try {
        console.log(`[joinAsHost] Searching for quiz with roomCode: ${roomCode} and hostPin: ${hostPin}.`);
        const quiz = await Quiz.findOne({ title: String(roomCode), hostPin: hostPin }); // Ensure roomCode is a string
        console.log(`[joinAsHost] Quiz query result for room ${roomCode}: ${quiz ? 'Found' : 'Not Found'}`);
        if (!quiz) {
          console.log(`[joinAsHost] Room ${roomCode} or host PIN not found for host.`);
          if (typeof callback === 'function') {
            callback({ success: false, message: 'Room not found or invalid host PIN' });
          }
          return;
        }

        // Update the hostId in the database for persistence
        quiz.hostId = socket.id;
        await quiz.save();
        console.log(`[joinAsHost] Updated hostId for room ${roomCode} in DB to ${socket.id}.`);

        socket.join(String(roomCode)); // Ensure roomCode is a string
        if (!activeRooms.has(roomCode)) {
          activeRooms.set(roomCode, {
            hostId: socket.id,
            quiz: quiz, // Store the retrieved quiz object
            participants: new Map(),
            answers: new Map()
          });
          console.log(`[joinAsHost] Initialized activeRooms for room ${roomCode} with quiz object.`);
        } else {
          // If room already exists in activeRooms, update its quiz object
          activeRooms.get(roomCode).hostId = socket.id;
          activeRooms.get(roomCode).quiz = quiz; // Update with latest quiz object from DB
          console.log(`[joinAsHost] Updated activeRooms for room ${roomCode} with new hostId and latest quiz object.`);
        }

        socket.emit('hostJoined', { message: 'Successfully joined as host', roomCode });

        const participantsInRoom = await Participant.find({ roomCode: String(roomCode) }); // Ensure roomCode is a string
        console.log(`[joinAsHost] Participants in room ${roomCode} retrieved on host join:`, participantsInRoom.map(p => p.username));
        io.to(roomCode).emit('currentParticipants', { participants: participantsInRoom });

        // If quiz is already active, send the current question to the re-joining host
        if (quiz.status === 'active' && quiz.currentQuestionIndex < quiz.questions.length) {
          console.log(`[joinAsHost] Quiz is active, sending current question to re-joining host ${socket.id}.`);
          const currentQuestion = quiz.questions[quiz.currentQuestionIndex];
          const room = activeRooms.get(roomCode);
          const initialAnswersCount = {};
          if (currentQuestion && currentQuestion.options) {
            currentQuestion.options.forEach(option => {
              initialAnswersCount[option] = room.answers.get(option) || 0; // Populate with existing counts if any
            });
          }
          
          socket.emit('quizStarting', { // Re-emit quizStarting for the re-joining host
            message: 'Quiz is starting',
            totalQuestions: quiz.questions.length
          });

          socket.emit('newQuestion', {
            question: {
              question: currentQuestion.question,
              options: currentQuestion.options,
              timeLimit: currentQuestion.timeLimit,
            },
            questionIndex: quiz.currentQuestionIndex,
            timeLimit: currentQuestion.timeLimit,
          });
          // Calculate actual time left based on currentQuestionStartTime
          const elapsedTime = Math.floor((new Date() - new Date(quiz.currentQuestionStartTime)) / 1000);
          const calculatedTimeLeft = Math.max(0, currentQuestion.timeLimit - elapsedTime);
          
          socket.emit('timerUpdate', { timeLeft: calculatedTimeLeft });
          socket.emit('updateAnswers', { answersCount: initialAnswersCount });
        }

        if (typeof callback === 'function') {
          callback({ success: true, message: 'Successfully joined as host' });
        }

      } catch (error) {
        console.error('[joinAsHost] Error joining as host:', error);
        if (typeof callback === 'function') {
          callback({ success: false, message: 'Error joining as host' });
        }
      }
    });

    socket.on('joinRoom', async ({ roomCode, name }, callback) => {
      try {
        console.log(`[joinRoom] Socket ${socket.id} attempting to join room ${roomCode} as ${name}.`);
        const quiz = await Quiz.findOne({ title: String(roomCode) });  // Ensure roomCode is a string
        
        if (!quiz) {
          console.log(`[joinRoom] Room ${roomCode} not found.`);
          if (typeof callback === 'function') {
            callback({ success: false, error: 'Room not found' });
          }
          return;
        }

        let participant = await Participant.findOne({ roomCode: String(roomCode), username: name }); // Ensure roomCode is a string

        if (participant) {
          participant.socketId = socket.id;
          participant.lastActive = new Date();
          await participant.save();
          console.log(`[joinRoom] Participant ${name} reconnected to room ${roomCode}. Saved participant:`, participant.username);
        } else {
          participant = new Participant({
            username: name,
            roomCode: String(roomCode), // Ensure roomCode is a string
            socketId: socket.id,
            score: 0,
            correctAnswers: 0
          });
          await participant.save();
          console.log(`[joinRoom] New participant ${name} joined room ${roomCode}. Saved participant:`, participant.username);
        }

        socket.join(String(roomCode)); // Ensure roomCode is a string
        // Only emit 'joined' if a callback was provided, as it's an acknowledgement
        if (typeof callback === 'function') {
            socket.emit('joined', { message: 'Successfully joined the room', roomCode });
        }
        
        const room = activeRooms.get(roomCode);
        if (room) {
          room.participants.set(socket.id, { id: socket.id, username: name, score: participant.score });
        }

        const participantsInRoom = await Participant.find({ roomCode: String(roomCode) }); // Ensure roomCode is a string
        console.log(`[joinRoom] Participants in room ${roomCode} after join:`, participantsInRoom.map(p => p.username));
        io.to(roomCode).emit('participantJoined', { 
          participants: participantsInRoom 
        });

        if (typeof callback === 'function') {
          callback({ success: true, message: 'Successfully joined the room' });
        }

      } catch (error) {
        console.error('[joinRoom] Error joining room:', error);
        if (typeof callback === 'function') {
          callback({ success: false, error: 'Failed to join room' });
        }
      }
    });

    socket.on('submitAnswer', async ({ roomCode, questionIndex, selectedOption }, callback) => {
      console.log(`[submitAnswer] Socket ${socket.id} submitting answer for room ${roomCode}, question ${questionIndex}, option ${selectedOption}.`);
      try {
        const quiz = await Quiz.findOne({ roomCode: String(roomCode) }); // Ensure roomCode is a string
        if (!quiz) {
          console.log(`[submitAnswer] Quiz not found for room ${roomCode}.`);
          if (typeof callback === 'function') {
            return callback({ success: false, message: 'Quiz not found.' });
          }
        }
        
        const room = activeRooms.get(roomCode);
        const participant = await Participant.findOne({ socketId: socket.id, roomCode: String(roomCode) }); // Ensure roomCode is a string

        if (!room || !participant) {
          console.warn(`[submitAnswer] Room ${roomCode} not active or participant ${socket.id} not found.`);
          if (typeof callback === 'function') {
            return callback({ success: false, message: 'Room not active or participant not found.' });
          }
        }

        if (quiz.currentQuestionIndex !== questionIndex) {
          console.warn(`[submitAnswer] Participant ${participant.username} submitted answer for wrong question index. Expected ${quiz.currentQuestionIndex}, got ${questionIndex}.`);
          if (typeof callback === 'function') {
            return callback({ success: false, message: 'Answer submitted for an incorrect question.' });
          }
        }

        const currentQuestion = quiz.questions[questionIndex];
        if (!currentQuestion) {
          console.error(`[submitAnswer] Current question not found for index ${questionIndex} in quiz ${roomCode}.`);
          if (typeof callback === 'function') {
            return callback({ success: false, message: 'Question not found.' });
          }
        }

        const isCorrect = currentQuestion.correctAnswer === selectedOption;
        
        // Store answer for score calculation later
        room.answers.set(socket.id, {
          questionIndex,
          answer: selectedOption,
          isCorrect,
        });
        console.log(`[submitAnswer] Answer from ${participant.username} for question ${questionIndex} isCorrect: ${isCorrect}.`);

        // Update counts for host's live view
        const answersCount = {};
        currentQuestion.options.forEach(option => {
          answersCount[option] = Array.from(room.answers.values()).filter(
            (ans) => ans.questionIndex === questionIndex && ans.answer === option
          ).length;
        });
        io.to(roomCode).emit('updateAnswers', { answersCount });
        console.log(`[submitAnswer] Emitted 'updateAnswers' to room ${roomCode}.`);

        if (typeof callback === 'function') {
          callback({ success: true, message: 'Answer submitted', isCorrect });
        }
      } catch (error) {
        console.error('[submitAnswer] Error submitting answer:', error);
        if (typeof callback === 'function') {
          callback({ success: false, message: 'Failed to submit answer' });
        }
      }
    });

    socket.on('hostNextQuestion', async ({ roomCode }, callback) => {
      console.log(`[hostNextQuestion] Host ${socket.id} requesting next question for room ${roomCode}.`);
      try {
        // Re-fetch quiz from DB to ensure it's the latest version
        const quiz = await Quiz.findOne({ roomCode: String(roomCode) }); 
        console.log(`[hostNextQuestion] Quiz found via findOne for room ${roomCode}: ${!!quiz}.`);

        if (!quiz || quiz.hostId !== socket.id) {
          console.warn(`[hostNextQuestion] Unauthorized next question attempt for room ${roomCode} by socket ${socket.id}. Quiz found: ${!!quiz}. Host ID match: ${quiz && quiz.hostId === socket.id}.`);
          if (typeof callback === 'function') {
            return callback({ success: false, message: 'Quiz not found or not authorized to advance.' });
          }
        }
        // Update activeRooms with the latest quiz object from the database
        if (activeRooms.has(roomCode)) {
          activeRooms.get(roomCode).quiz = quiz;
          console.log(`[hostNextQuestion] Updated activeRooms for room ${roomCode} with latest quiz object.`);
        } else {
          console.warn(`[hostNextQuestion] Room ${roomCode} not found in activeRooms during hostNextQuestion. This is unexpected. Initializing.`);
          // This case should ideally not happen if joinAsHost works correctly, but as a fallback:
          activeRooms.set(roomCode, { hostId: socket.id, quiz: quiz, participants: new Map(), answers: new Map() });
        }

        // **Crucial Change:** Advance the quiz here, only if the previous `calculateScoresAndEmitLeaderboard` finished.
        // Since frontend automatically calls this after 10s, we rely on it.
        console.log(`[hostNextQuestion] Calling advanceQuiz for room ${roomCode}.`);
        await advanceQuiz(String(roomCode), quiz, io); 
        if (typeof callback === 'function') {
          callback({ success: true, message: 'Advanced to next question.' });
        }

      } catch (error) {
        console.error('[hostNextQuestion] Error advancing to next question:', error);
        if (typeof callback === 'function') {
          callback({ success: false, message: 'Failed to advance question.' });
        }
      }
    });

    socket.on('startQuiz', async ({ roomCode }, callback) => {
      console.log(`[startQuiz] Host ${socket.id} is starting quiz for room ${roomCode}.`);
      try {
        const quiz = await Quiz.findOne({ roomCode: String(roomCode) }); // Ensure roomCode is a string
        if (!quiz || quiz.hostId !== socket.id) {
          console.warn(`[startQuiz] Unauthorized start attempt for room ${roomCode} by socket ${socket.id}. Quiz found: ${!!quiz}. Host ID match: ${quiz && quiz.hostId === socket.id}.`);
          if (typeof callback === 'function') {
            return callback({ success: false, message: 'Quiz not found or not authorized to start.' });
          }
        }

        quiz.status = 'active';
        quiz.currentQuestionIndex = 0; // Ensure quiz starts from the first question
        await quiz.save();
        console.log(`[startQuiz] Quiz ${roomCode} status set to active and currentQuestionIndex reset.`);

        // Update activeRooms with the latest quiz object from the database
        if (activeRooms.has(roomCode)) {
          activeRooms.get(roomCode).quiz = quiz;
          console.log(`[startQuiz] Updated activeRooms for room ${roomCode} with latest quiz object.`);
        } else {
          console.warn(`[startQuiz] Room ${roomCode} not found in activeRooms during startQuiz. Initializing.`);
          // This case should ideally not happen if joinAsHost works correctly, but as a fallback:
          activeRooms.set(roomCode, { hostId: socket.id, quiz: quiz, participants: new Map(), answers: new Map() });
        }

        console.log(`[startQuiz] Emitting 'quizStarting' to room ${roomCode}.`);
        io.to(roomCode).emit('quizStarting', { 
          message: 'Quiz is starting!',
          totalQuestions: quiz.questions.length
        });

        console.log(`[startQuiz] Calling sendQuestion for room ${roomCode}.`);
        await sendQuestion(roomCode, quiz, io);

        if (typeof callback === 'function') {
          callback({ success: true, message: 'Quiz started successfully.' });
        }

      } catch (error) {
        console.error('[startQuiz] Error starting quiz:', error);
        if (typeof callback === 'function') {
          callback({ success: false, message: 'Failed to start quiz.' });
        }
      }
    });

    socket.on('cancelQuiz', async ({ roomCode }, callback) => {
      console.log(`[cancelQuiz] Host ${socket.id} is cancelling quiz for room ${roomCode}.`);
      try {
        const quiz = await Quiz.findOne({ roomCode: String(roomCode) }); // Ensure roomCode is a string
        if (!quiz || quiz.hostId !== socket.id) {
          console.warn(`[cancelQuiz] Unauthorized cancel attempt for room ${roomCode} by socket ${socket.id}.`);
          if (typeof callback === 'function') {
            return callback({ success: false, message: 'Quiz not found or not authorized to cancel.' });
          }
        }

        // Clear any active timer for this room
        if (questionTimers.has(roomCode)) {
          clearInterval(questionTimers.get(roomCode));
          questionTimers.delete(roomCode);
          console.log(`[cancelQuiz] Cleared timer for room ${roomCode}.`);
        }

        quiz.status = 'cancelled';
        await quiz.save();
        console.log(`[cancelQuiz] Quiz ${roomCode} status set to cancelled and saved.`);

        io.to(roomCode).emit('quizCancelled', { message: 'Quiz has been cancelled by the host.' });
        activeRooms.delete(roomCode); // Clean up active room
        console.log(`[cancelQuiz] Emitted 'quizCancelled' to room ${roomCode} and removed from activeRooms.`);

        // Also delete all participants for this room from the database
        await Participant.deleteMany({ roomCode: String(roomCode) }); // Ensure roomCode is a string
        console.log(`[cancelQuiz] Deleted participants for room ${roomCode} from database.`);

        if (typeof callback === 'function') {
          callback({ success: true, message: 'Quiz cancelled successfully.' });
        }
      } catch (error) {
        console.error('[cancelQuiz] Error cancelling quiz:', error);
        if (typeof callback === 'function') {
          callback({ success: false, message: 'Failed to cancel quiz.' });
        }
      }
    });

    socket.on('getParticipants', async ({ roomCode }, callback) => {
      console.log(`[getParticipants] Socket ${socket.id} requesting participants for room ${roomCode}.`);
      try {
        const participants = await Participant.find({ roomCode: String(roomCode) }); // Ensure roomCode is a string
        if (typeof callback === 'function') {
          callback({ success: true, participants: participants });
        }
        console.log(`[getParticipants] Sent ${participants.length} participants for room ${roomCode}.`);
      } catch (error) {
        console.error('[getParticipants] Error getting participants:', error);
        if (typeof callback === 'function') {
          callback({ success: false, error: 'Failed to get participants' });
        }
      }
    });

    socket.on('disconnect', async () => {
      console.log('Client disconnected:', socket.id);

      // Check if the disconnected socket was a host
      let roomCode = null;
      let isHost = false;
      for (const [key, room] of activeRooms.entries()) {
        if (room.hostId === socket.id) {
          roomCode = key;
          isHost = true;
          break;
        }
        // Also check if participant is in this room
        // Iterate over participants map to find if the disconnected socket.id belongs to a participant
        if (room && Array.from(room.participants.keys()).includes(socket.id)) {
            roomCode = key; // Found room for participant
            break;
        }
      }

      if (roomCode) {
        if (isHost) {
          console.log(`Host ${socket.id} disconnected from room ${roomCode}. Attempting to cancel quiz.`);
          const quiz = await Quiz.findOne({ roomCode: String(roomCode) }); // Ensure roomCode is a string
          if (quiz) {
            // Clear any active timer for this room if host disconnects
            if (questionTimers.has(roomCode)) {
                clearInterval(questionTimers.get(roomCode));
                questionTimers.delete(roomCode);
                console.log(`[disconnect] Cleared timer for room ${roomCode} due to host disconnect.`);
            }

            quiz.status = 'cancelled';
            await quiz.save();
            io.to(roomCode).emit('quizCancelled', { message: 'Host disconnected. Quiz cancelled.' });
            
            // Only delete from activeRooms here IF quiz is definitely cancelled and all cleanup is done
            if (activeRooms.has(roomCode)) {
                activeRooms.delete(roomCode);
                console.log(`[disconnect] Removed room ${roomCode} from activeRooms map due to host disconnect.`);
            }

            // Also delete all participants for this room from the database
            await Participant.deleteMany({ roomCode: String(roomCode) }); 
            console.log(`[disconnect] Deleted participants for room ${roomCode} from database due to host disconnect.`);

          } else {
            console.warn(`[disconnect] Quiz not found in DB for disconnected host's room ${roomCode}.`);
            // Even if quiz not found in DB, try to clean up activeRooms if it exists there
            if (activeRooms.has(roomCode)) {
                activeRooms.delete(roomCode);
                console.log(`[disconnect] Removed room ${roomCode} from activeRooms (quiz not found in DB).`);
            }
          }
        } else {
          // A participant disconnected
          const room = activeRooms.get(roomCode);
          if (room && room.participants.has(socket.id)) {
            const disconnectedParticipant = room.participants.get(socket.id);
            room.participants.delete(socket.id);
            console.log(`Participant ${disconnectedParticipant.username} (${socket.id}) left room ${roomCode}.`);

            // Remove participant from database as well
            await Participant.deleteOne({ socketId: socket.id, roomCode: String(roomCode) }); 
            console.log(`[disconnect] Deleted participant ${disconnectedParticipant.username} from DB for room ${roomCode}.`);

            const participantsInRoom = await Participant.find({ roomCode: String(roomCode) }); // Refresh list
            io.to(roomCode).emit('participantLeft', { participants: participantsInRoom });
            console.log(`[disconnect] Emitted 'participantLeft' to room ${roomCode}. Remaining participants: ${participantsInRoom.length}.`);
          } else {
            console.warn(`[disconnect] Disconnected socket ${socket.id} was not a host and not found in active participants for room ${roomCode}. Attempting orphaned participant cleanup.`);
            // Attempt to remove participant from DB even if not in activeRooms (e.g., if activeRooms map was reset)
            const deletedCount = await Participant.deleteOne({ socketId: socket.id, roomCode: String(roomCode) }); // Ensure roomCode is used for lookup
            if (deletedCount.deletedCount > 0) {
              console.log(`[disconnect] Cleaned up orphaned participant record for socket ${socket.id} from database.`);
            } else {
                console.log(`[disconnect] No orphaned participant record found for socket ${socket.id}.`);
            }
          }
        }
      } else {
        console.log(`[disconnect] Disconnected socket ${socket.id} not associated with any active room.`);
      }
    });
  });

  // Error handling for MongoDB connection
  mongoose.connection.on('error', (err) => {
    console.error('MongoDB connection error:', err);
  });

  mongoose.connection.once('open', () => {
    console.log('Connected to MongoDB successfully');
  });

})

// Get all quizzes (for testing)
app.get('/api/quizzes', async (req, res) => {
  try {
    const quizzes = await Quiz.find();
    res.json({
      success: true,
      count: quizzes.length,
      quizzes
    });
  } catch (error) {
    console.error('Error fetching quizzes:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch quizzes'
    });
  }
});

// Get quiz by room code
app.get('/api/quiz/:roomCode', async (req, res) => {
  try {
    const { roomCode } = req.params;
    const isHost = req.query.isHost === 'true';
    
    const quiz = await Quiz.findOne({ roomCode });
    if (!quiz) {
      return res.status(404).json({ 
        success: false, 
        error: 'Quiz not found' 
      });
    }

    const quizData = {
      _id: quiz._id,
      roomCode: quiz.roomCode,
      status: quiz.status,
      currentQuestionIndex: quiz.currentQuestionIndex || 0,
      questions: isHost ? quiz.questions : quiz.questions.map(q => ({
        question: q.question,
        options: q.options,
        timeLimit: q.timeLimit
      })),
      participants: quiz.participants || []
    };
    res.json({ success: true, quiz: quizData });
  } catch (error) {
    console.error('Error getting quiz by room code:', error);
    res.status(500).json({ success: false, error: 'Failed to get quiz' });
  }
});

// Start the server
const PORT = process.env.PORT || 5000;
server.listen(PORT, () => {
  console.log(`🚀 Server running on port ${PORT}`);
  console.log(`🌐 WebSocket server running on ws://localhost:${PORT}`);
});

// Handle unhandled promise rejections
process.on('unhandledRejection', (err) => {
  console.error('Unhandled Rejection:', err);
  // Close server & exit process
  server.close(() => process.exit(1));
});

// Handle uncaught exceptions
process.on('uncaughtException', (err) => {
  console.error('Uncaught Exception:', err);
  // Close server & exit process
  server.close(() => process.exit(1));
});

// Handle server errors
server.on('error', (error) => {
  console.error('Server error:', error);
}); 