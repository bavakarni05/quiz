require('dotenv').config();
const mongoose = require('mongoose');

async function testConnection() {
  try {
    console.log('Testing MongoDB connection...');
    
    // Get the connection string from environment variables
    const mongoURI = process.env.MONGODB_URI;
    console.log('Using connection string:', mongoURI.replace(/:[^:]*@/, ':***@'));
    
    // Connect to MongoDB
    const conn = await mongoose.connect(mongoURI, {
      serverSelectionTimeoutMS: 5000,
      connectTimeoutMS: 5000,
    });
    
    console.log('✅ Successfully connected to MongoDB!');
    console.log('Host:', conn.connection.host);
    console.log('Database:', conn.connection.db.databaseName);
    
    // List all collections
    const collections = await conn.connection.db.listCollections().toArray();
    console.log('\n📂 Collections:');
    collections.forEach((col, i) => console.log(`${i + 1}. ${col.name}`));
    
  } catch (error) {
    console.error('❌ Connection failed!');
    console.error('Error:', error.message);
    
    if (error.name === 'MongooseServerSelectionError') {
      console.log('\n🔍 Troubleshooting:');
      console.log('1. Check your internet connection');
      console.log('2. Verify your MongoDB Atlas IP whitelist');
      console.log('3. Check if the database user has correct permissions');
      console.log('4. Verify the connection string in .env file');
    }
    
  } finally {
    // Close the connection
    await mongoose.connection.close();
    process.exit(0);
  }
}

testConnection();
