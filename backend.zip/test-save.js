const mongoose = require('mongoose');
const { Quiz } = require('./models/Quiz');

async function testSave() {
  try {
    // Connect to MongoDB
    const mongoURI = 'mongodb://127.0.0.1:27017/quizmaster?directConnection=true';
    console.log('Connecting to MongoDB...');
    await mongoose.connect(mongoURI, {
      serverSelectionTimeoutMS: 5000,
    });
    console.log('✅ Connected to MongoDB');

    // Create a test quiz
    const testQuiz = new Quiz({
      roomCode: 'TEST' + Date.now(),
      hostId: 'test-host',
      questions: [{
        question: 'What is 2+2?',
        options: ['3', '4', '5', '6'],
        correctAnswer: '4',
        timeLimit: 30
      }],
      status: 'waiting'
    });

    console.log('Saving test quiz...');
    const savedQuiz = await testQuiz.save();
    console.log('✅ Quiz saved successfully!');
    console.log('Saved quiz ID:', savedQuiz._id);
    console.log('Room code:', savedQuiz.roomCode);

    // Verify the quiz exists in the database
    const foundQuiz = await Quiz.findById(savedQuiz._id);
    console.log('\nFound quiz in database:', foundQuiz ? '✅ Yes' : '❌ No');

  } catch (error) {
    console.error('❌ Error:', error.message);
    if (error.errors) {
      console.error('Validation errors:', error.errors);
    }
  } finally {
    await mongoose.connection.close();
    console.log('\n🔌 Disconnected from MongoDB');
  }
}

testSave();
