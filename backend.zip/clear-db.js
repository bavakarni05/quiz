const mongoose = require('mongoose');
const { Quiz } = require('./models/Quiz');

async function clearDatabase() {
  try {
    // Connect to MongoDB
    const mongoURI = process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/quizmaster';
    await mongoose.connect(mongoURI);
    console.log('✅ Connected to MongoDB');

    // Delete all quizzes
    const result = await Quiz.deleteMany({});
    console.log(`✅ Deleted ${result.deletedCount} quizzes`);

    // Verify the database is empty
    const count = await Quiz.countDocuments();
    console.log(`📊 Total quizzes in database: ${count}`);

    if (count === 0) {
      console.log('✅ Database is now empty');
    } else {
      console.log('❌ Failed to clear all quizzes');
    }
  } catch (error) {
    console.error('❌ Error clearing database:', error);
  } finally {
    await mongoose.connection.close();
    console.log('🔌 Disconnected from MongoDB');
    process.exit(0);
  }
}

clearDatabase();
