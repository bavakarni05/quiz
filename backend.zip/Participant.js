const mongoose = require('mongoose');

const participantSchema = new mongoose.Schema({
  username: {
    type: String,
    required: true,
    trim: true
  },
  roomCode: {
    type: String,
    required: true
  },
  socketId: {
    type: String,
    required: true
  },
  score: {
    type: Number,
    default: 0
  },
  correctAnswers: {
    type: Number,
    default: 0
  },
  answers: [{
    questionIndex: {
      type: Number,
      required: true
    },
    answer: {
      type: String,
      required: true
    },
    isCorrect: {
      type: Boolean,
      required: true
    },
    pointsEarned: {
      type: Number,
      required: true
    },
    timeTaken: {
      type: Number,
      required: true
    },
    timestamp: {
      type: Date,
      default: Date.now
    }
  }],
  isReady: {
    type: Boolean,
    default: false
  },
  joinedAt: {
    type: Date,
    default: Date.now
  },
  lastActive: {
    type: Date,
    default: Date.now
  }
});

// Update lastActive timestamp before saving
participantSchema.pre('save', function(next) {
  this.lastActive = new Date();
  next();
});

// Calculate total score
participantSchema.methods.calculateTotalScore = function() {
  return this.answers.reduce((total, answer) => total + answer.pointsEarned, 0);
};

// Get answer statistics
participantSchema.methods.getStats = function() {
  return {
    totalQuestions: this.answers.length,
    correctAnswers: this.correctAnswers,
    totalScore: this.score,
    averageTimePerQuestion: this.answers.reduce((total, answer) => total + answer.timeTaken, 0) / this.answers.length
  };
};

// Index for efficient querying
participantSchema.index({ roomCode: 1, username: 1 }, { unique: true });

const Participant = mongoose.model('Participant', participantSchema);

module.exports = Participant; 