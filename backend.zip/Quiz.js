const mongoose = require('mongoose');

const questionSchema = new mongoose.Schema({
  question: {
    type: String,
    required: true,
    trim: true
  },
  options: {
    type: [String],
      required: true,
    validate: {
      validator: function(v) {
        return v.length === 4;
      },
      message: 'Each question must have exactly 4 options'
    }
  },
  correctAnswer: {
    type: String,
    required: true,
    trim: true
  },
  timeLimit: {
    type: Number,
    default: 30,
    min: 5,
    max: 300
  }
});

const quizSchema = new mongoose.Schema({
  roomCode: {
    type: String,
    required: true,
    unique: true,
    trim: true
  },
  title: {
    type: String,
    required: true,
    trim: true
  },
  hostId: {
    type: String,
    required: true
  },
  hostPin: {
    type: String,
    required: true,
    unique: true,
    trim: true,
    minlength: 4,
    maxlength: 4
  },
  questions: {
    type: [questionSchema],
    required: true,
    validate: {
      validator: function(v) {
        return v.length > 0;
      },
      message: 'Quiz must have at least one question'
    }
  },
  status: {
    type: String,
    enum: ['waiting', 'active', 'completed'],
    default: 'waiting'
  },
  currentQuestionIndex: {
    type: Number,
    default: 0
  },
  currentQuestionStartTime: {
    type: Date,
    default: null // Will be set when a question starts
  },
  participants: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Participant'
  }],
  createdAt: {
    type: Date,
    default: Date.now
  },
  completedAt: {
    type: Date
  }
});

// Generate a unique room code
quizSchema.statics.generateRoomCode = async function() {
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let roomCode;
  let isUnique = false;
  
  while (!isUnique) {
    roomCode = '';
  for (let i = 0; i < 6; i++) {
      roomCode += characters.charAt(Math.floor(Math.random() * characters.length));
  }
    
    const existingQuiz = await this.findOne({ roomCode });
    if (!existingQuiz) {
      isUnique = true;
    }
  }
  
  return roomCode;
};

// Helper to generate a unique host PIN
const generateHostPin = () => {
  const characters = '0123456789';
  let pin = '';
  for (let i = 0; i < 4; i++) {
    pin += characters.charAt(Math.floor(Math.random() * characters.length));
  }
  return pin;
};

// Validate that correct answer is one of the options
quizSchema.pre('save', function(next) {
  this.questions.forEach((question, index) => {
    if (!question.options.includes(question.correctAnswer)) {
      next(new Error(`Question ${index + 1}: Correct answer must be one of the options`));
    }
  });
  next();
});

const Quiz = mongoose.model('Quiz', quizSchema);

module.exports = { Quiz, generateHostPin }; 