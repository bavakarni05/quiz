const mongoose = require('mongoose');

async function checkDatabase() {
  try {
    // Connect to MongoDB
    const mongoURI = 'mongodb://127.0.0.1:27017/quizmaster?directConnection=true';
    console.log('Connecting to MongoDB...');
    await mongoose.connect(mongoURI, {
      serverSelectionTimeoutMS: 5000,
    });
    console.log('✅ Connected to MongoDB');

    // Get database name
    const db = mongoose.connection.db;
    console.log(`📊 Database: ${db.databaseName}`);

    // List all collections
    const collections = await db.listCollections().toArray();
    console.log('\n📂 Collections:');
    collections.forEach((collection, index) => {
      console.log(`${index + 1}. ${collection.name}`);
    });

    // Count documents in each collection
    console.log('\n📝 Document counts:');
    for (const collection of collections) {
      const count = await db.collection(collection.name).countDocuments();
      console.log(`- ${collection.name}: ${count} documents`);
    }

    // Check if 'quizzes' collection exists and show sample data
    const quizzes = db.collection('quizzes');
    const quizCount = await quizzes.countDocuments();
    console.log(`\n🔍 Found ${quizCount} quizzes in the database`);
    
    if (quizCount > 0) {
      console.log('\n📄 Sample quiz document:');
      const sampleQuiz = await quizzes.findOne();
      console.log(JSON.stringify(sampleQuiz, null, 2));
    }

  } catch (error) {
    console.error('❌ Error:', error.message);
  } finally {
    // Close the connection
    await mongoose.connection.close();
    console.log('\n🔌 Disconnected from MongoDB');
  }
}

checkDatabase();
